-- Create the database
CREATE DATABASE IF NOT EXISTS bionexg;

-- Use the created database
USE bionexg;

-- Create the 'users' table
CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'employee') NOT NULL
);

-- Create the 'tasks' table
CREATE TABLE IF NOT EXISTS tasks (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    task_name VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('pending', 'in progress', 'completed') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    deadline DATE,
    assigned_to INT(11),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);

-- Insert example admin and employee users
INSERT INTO users (username, password, role) VALUES
('admin', MD5('123'), 'admin'),
('employee', MD5('123'), 'employee');
