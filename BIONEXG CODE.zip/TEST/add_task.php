<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_name = $_POST['task_name'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $priority = $_POST['priority'];
    $deadline = $_POST['deadline'];
    $assigned_to = $_POST['assigned_to'];

    $conn = new mysqli('localhost', 'root', '', 'bionexg');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO tasks (task_name, description, status, priority, deadline, assigned_to) VALUES ('$task_name', '$description', '$status', '$priority', '$deadline', '$assigned_to')";

    if ($conn->query($sql) === TRUE) {
        echo "New task created successfully. <a href='admin_dashboard.php'>Go back to dashboard</a>";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>

<!-- Task Creation Form HTML -->
<form method="POST" action="add_task.php">
<link rel="stylesheet" href="style-add_task.css">

    <input type="text" name="task_name" placeholder="Task Name" required>
    <textarea name="description" placeholder="Description" required></textarea>
    <select name="status" required>
        <option value="pending">Pending</option>
        <option value="in progress">In Progress</option>
        <option value="completed">Completed</option>
    </select>
    <select name="priority" required>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
    </select>
    <input type="date" name="deadline" required>
    <input type="text" name="assigned_to" placeholder="Assigned to" required>
    <button type="submit">Add Task</button>
</form>
